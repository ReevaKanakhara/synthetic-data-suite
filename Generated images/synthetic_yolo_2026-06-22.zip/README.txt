Synthetic Data Suite Export
Format: YOLO
Date:   2026-06-22
Images: 1
Annotations: 2

Usage: Use with Ultralytics YOLOv8 — point your dataset YAML to this folder
